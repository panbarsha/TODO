export interface TodoItem {
  _id?: string;       // Optional for new todos
  text: string;
  completed?: boolean;
}
